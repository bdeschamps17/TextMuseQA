//
//  Category.m
//  TextMuse
//
//  Created by Peter Tucker on 3/5/15.
//  Copyright (c) 2015 WhitworthCS. All rights reserved.
//

#import "MessageCategory.h"

@implementation MessageCategory

-(id)initWithName:(NSString*)n {
    [self setName:n];
    
    return self;
}

@end
