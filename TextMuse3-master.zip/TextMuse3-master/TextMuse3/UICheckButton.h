//
//  UICheckButton.h
//  TextMuse3
//
//  Created by Peter Tucker on 4/25/15.
//  Copyright (c) 2015 LaLoosh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserContact.h"

@interface UICheckButton : UIButton

@property id extra;

@end
