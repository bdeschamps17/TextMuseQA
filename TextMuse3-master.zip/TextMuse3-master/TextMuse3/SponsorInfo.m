//
//  SponsorInfo.m
//  TextMuse
//
//  Created by Peter Tucker on 11/23/14.
//  Copyright (c) 2014 WhitworthCS. All rights reserved.
//

#import "SponsorInfo.h"

@implementation SponsorInfo

@end
