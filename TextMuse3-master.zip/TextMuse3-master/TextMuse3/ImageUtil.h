//
//  ImageUtil.h
//  TextMuse3
//
//  Created by Peter Tucker on 5/7/15.
//  Copyright (c) 2015 LaLoosh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageUtil : NSObject

+(UIImage*) scaleImage:(UIImage*)img forFrame:(CGRect)frame;

@end
